﻿using EKZ.Class;
using EKZ.DB;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EKZ.Pages
{
    /// <summary>
    /// Логика взаимодействия для Employyer.xaml
    /// </summary>
    public partial class Employyer : Page
    {
        public static DB.EkzEntities ekzEntities = connector.GetDatabase();
        public static ObservableCollection<Employee> employees { get; set; }
        public static ObservableCollection<Position> positions { get; set; }
        public static ObservableCollection<Department> department { get; set; }
        private Employee selectedEmployee = null;
        private string searchText;
        public Employyer()
        {
            InitializeComponent();
            employees= new ObservableCollection<DB.Employee>(ekzEntities.Employee.ToList());
            positions= new ObservableCollection<DB.Position>(ekzEntities.Position.ToList());
            department= new ObservableCollection<Department>(ekzEntities.Department.ToList());
            ListViewName.ItemsSource=employees;
            DepartmentAdd.ItemsSource = department;
            PosititonAdd.ItemsSource = positions;
            DepartmentAdd.SelectedIndex= 0;
            PosititonAdd.SelectedIndex= 0;
            DataContext = this;
        }


       
        private void CreateNewEmployee(object sender, RoutedEventArgs e)
        {
            selectedEmployee = new Employee();
            spEmployee.DataContext = selectedEmployee;
            ekzEntities.Employee.Add(selectedEmployee);
            employees.Add(selectedEmployee);
            ListViewName.SelectedItem = selectedEmployee;
            SaveBut.IsEnabled = true;
        }
        private void EmployeeChanged(object sender, SelectionChangedEventArgs e)
        {
            selectedEmployee = ListViewName.SelectedItem as Employee;
            spEmployee.DataContext = selectedEmployee;
            if(selectedEmployee != null)
            {
                SaveBut.IsEnabled = true;
            }else
            {
                SaveBut.IsEnabled = false;
            }
        }

        private void SaveChanges(object sender, RoutedEventArgs e)
        {
            try
            {
                ekzEntities.SaveChanges();
                MessageBox.Show("OK");
            }
            catch(Exception exception)
            {
                MessageBox.Show("Упс..."+exception.Message);
            }
        }

        private void DelEmployee(object sender, RoutedEventArgs e)
        {
            Employee employee=ListViewName.SelectedItem as Employee;
            ekzEntities.Employee.Remove(selectedEmployee);
            employees.Remove(selectedEmployee);
            ekzEntities.SaveChanges();

        }

        private void SearchTextChanged(object sender, TextChangedEventArgs e)
        {
            searchText = "";
            TextBox textBox = sender as TextBox;
            if(textBox != null)
            {
                searchText= textBox.Text.Trim();
            }
        }
    }
}
