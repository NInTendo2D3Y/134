﻿using EKZ.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EKZ.Class
{
    public static class Nextpage
    {
        private static Welcome welcome;
        private static Employyer employyer;
        public static Welcome GetWelcome()
        {
            if (welcome == null) 
            { welcome = new Welcome(); }
            return welcome;
            
        }
        public static Employyer GetEmployyer()
        {
            if (employyer == null)
            { employyer = new Employyer(); }
            return employyer;

        }

    }
}
