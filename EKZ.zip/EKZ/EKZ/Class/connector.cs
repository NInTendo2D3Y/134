﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EKZ.Class
{
    public static class connector
    {
        private static DB.EkzEntities DatabaseConnector;

        public static DB.EkzEntities GetDatabase()
        {
            if(DatabaseConnector == null)
            {
                DatabaseConnector = new DB.EkzEntities();
            }
            return DatabaseConnector;
        }

    }
}
